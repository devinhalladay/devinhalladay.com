function setup() {
  // The Basics
  createCanvas(500, 500);
  background('#171C20');
  colorMode(HSB);
}

function draw() {
  // Nothing here yet
}
